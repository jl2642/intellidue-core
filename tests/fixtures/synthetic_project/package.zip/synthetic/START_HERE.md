# Synthetic fixture
